﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GDMS.Repository.Interfaces
{
	public interface IRepository<T> where T : class
	{
		IEnumerable<T> Get();
		T Get(int id);
		string Add(T entity);
		bool Delete(int id);
		string Update(T entity);
		string SFTpFileUpdate(T entity);

		bool UpdateFileCount(int FileCount, string CustomerName);

	//	T GetFileStatus(int RegionID,int CustomerID);
		IEnumerable<T> GetFileStatus(int RegionID, int CustomerID);

	//	IEnumerable<T> GetsyncFiles(int BranchID, int DepartmentID);

		//IEnumerable<T> GetDetails();

		//bool ActiveDeActive(T entity);
	}
}
