﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GDMS.Repository.Interfaces
{
	public interface IMappingchkRepository<T> where T : class
	{
		IEnumerable<T> Get();
		T Get(int id);
		string Add(T entity);
		bool Delete(int id);
        bool Delete(int id,int userid);
        string Update(T entity);

        string regionmappingCreate(T entity);
        //  string regionmappingCreate(T entity);

        string PDDataUpload(T entity);        

        IEnumerable<T> GetDetails(int id);

        IEnumerable<T> GetDetailsRegion(int id);     


        IEnumerable<T> GetBranchDetailsRegionWise(int id);

        IEnumerable<T> GetBranchDetailsUserWise(int id);

        IEnumerable<T> GetBranchByDeptUserWise(int id,int deptid);


        

        //bool ActiveDeActive(T entity);
    }
}
