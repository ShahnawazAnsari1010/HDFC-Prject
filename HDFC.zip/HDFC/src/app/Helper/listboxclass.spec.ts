import { Listboxclass } from './listboxclass';

describe('Listboxclass', () => {
  it('should create an instance', () => {
    expect(new Listboxclass()).toBeTruthy();
  });
});
