
import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-charts",
  templateUrl: "charts.component.html"
})
export class ChartsComponent implements OnInit {
  constructor() {}

  ngOnInit() {
  
  }
} 
