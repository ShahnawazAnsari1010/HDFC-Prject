import { Globalconstants } from "../../../Helper/globalconstants";
import { OnlineExamServiceService } from "../../../Services/online-exam-service.service";
import { Component, OnInit, TemplateRef } from "@angular/core";
import { BsModalService, BsModalRef } from "ngx-bootstrap/modal";
import { FormGroup, FormBuilder, Validators, FormControl, FormArray } from "@angular/forms";
import { ToastrService } from "ngx-toastr";
import { Router, ActivatedRoute } from '@angular/router';

import swal from "sweetalert2";
// import { Listboxclass } from '../../../Helper/Listboxclass';
export enum SelectionType {
  single = "single",
  multi = "multi",
  multiClick = "multiClick",
  cell = "cell",
  checkbox = "checkbox",
}
@Component({
  selector: "app-Quicksearch",
  templateUrl: "Quicksearch.component.html",
  styleUrls : ["Quicksearch.component.css"]
})
export class QuicksearchComponent implements OnInit {

  entries: number = 10;
  selected: any[] = [];
  temp = [];
  activeRow: any;
  SelectionType = SelectionType;
  modalRef: BsModalRef;
  isReadonly = true;
  _TemplateList :any;
  first:any=0;
  rows:any=0
  _HeaderList:any;
  //_ColNameList:any;
  _IndexList:any;
   
  QuicksearchForm: FormGroup;
  ContentSearchForm: FormGroup;
  SAPCODEForm: FormGroup;
  InwardForm: FormGroup;  
  submitted = false;
  _DeptList:any;
  Reset = false;
  sMsg: string = '';
  
  _FileNo:any=""; 
   
  isDisabled = false;
   
// _Replacestr:any="D:/WW/14-Jully-2020/UI/src/assets";
   
  _FilteredList :any; 
  _IndexPendingList:any;
  bsValue = new Date();

  _ColNameList = ["BatchNo", "PODNo","LANNo","CustomerName","ApplicationNo","JCCode","JCName","FinalRemarks","DisbursedMonth","CBSCUSTIC","ProductCode","DocumentType","FileNo","CartonNo", "Status", "FileStatus", "Courier","Batchstatus","AcknowledgeDate","BRInwardDate","BRInwardBy","AuditorBy","AuditorDate","ReturnFromAuditirDate","ReturnFromAuditirBy" ,"PDCBarcode","PropertyBarcode","FRackNo","PDCRackNo","PRRackNo","OutwardDate","OutwardBy"];

   
  constructor(
    private modalService: BsModalService,
    public toastr: ToastrService,
    private formBuilder: FormBuilder,
    private _onlineExamService: OnlineExamServiceService,
    private _global: Globalconstants,
    private route: ActivatedRoute,
    private router: Router,
  ){}
  ngOnInit(){
    document.body.classList.add('data-entry');
    this.ContentSearchForm = this.formBuilder.group({
      SearchBy: ["0", Validators.required],
      FileNo: ['', Validators.required],
      User_Token: localStorage.getItem('User_Token') ,
      CreatedBy: localStorage.getItem('UserID') ,
      
    });

  
    this.GetIndexListPending();
  //  this.GetFilterSearch();
    //this.geDoctypeList();
    
    this.ContentSearchForm.controls['SearchBy'].setValue("0");
    
    this.isReadonly = false;  

    this.isDisabled = false;
  }


  GetIndexListPending() {     
     

    const apiUrl = this._global.baseAPIUrl + 'Inward/GetPODDetailsFulletronSearch?user_Token='+ localStorage.getItem('User_Token');
    this._onlineExamService.getAllData(apiUrl).subscribe((data: {}) => {     
    this._IndexPendingList = data;
    this._FilteredList = data;
   // this._ColNameList = data;
    this.prepareTableData(this._FilteredList, this._IndexPendingList);

 //  console.log("IndexListPending",data);
      //this.itemRows = Array.from(Array(Math.ceil(this.adresseList.length/2)).keys())
    });
  }
  
  
  
  get f() { return this.QuicksearchForm.controls; }
  get t() { return this.f.tickets as FormArray; }

  onChangeTickets(e) {
    const numberOfTickets = e.target.value || 0;
    if (this.t.length < numberOfTickets) {
        for (let i = this.t.length; i < numberOfTickets; i++) {
            this.t.push(this.formBuilder.group({
                name: ['', Validators.required],
                email: ['', [Validators.required, Validators.email]]
            }));
        }
    } else {
        for (let i = this.t.length; i >= numberOfTickets; i--) {
            this.t.removeAt(i);
        }
    }
} 
   
    GetFilterSearch() {     
     

      const apiUrl = this._global.baseAPIUrl + 'Inward/SearchRecordsByFulletron?user_Token='+ localStorage.getItem('User_Token') +'&FileNo='+this.ContentSearchForm.get('FileNo').value+'&SearchBy='+this.ContentSearchForm.get('SearchBy').value;
      this._onlineExamService.getAllData(apiUrl).subscribe((data: {}) => {     
      this._IndexPendingList = data;
      this._FilteredList = data

      //this._IndexPendingList = data;
     // this._FilteredList = data;
     // this._ColNameList = data;
      this.prepareTableData(this._FilteredList, this._IndexPendingList);


   //  console.log("IndexListPending",data);
        //this.itemRows = Array.from(Array(Math.ceil(this.adresseList.length/2)).keys())
      });
    }
   

    OnReset()
    {
    this.Reset = true;
    this.QuicksearchForm.reset();
    
    this.isReadonly = false;
    
    }
  
    checkDateFormat(date) {
      if(date == 'Invalid Date') {
        return false;
      }
      return true;
    }
  
    hidepopup()
{
 // this.modalService.hide;
  this.modalRef.hide();
  //this.modalRef.hide
}

 
 
 
 
  entriesChange($event) {
    this.entries = $event.target.value;
  }
 
  onSelect({ selected }) {
    this.selected.splice(0, this.selected.length);
    this.selected.push(selected);
  }
  onActivate(event) {
    this.activeRow = event.row;
  }

  ngOnDestroy() {
    document.body.classList.remove('data-entry')
  }

 
    showmessage(data:any)
    {
      this.toastr.show(
        '<div class="alert-text"</div> <span class="alert-title" data-notify="title">Validation ! </span> <span data-notify="message"> '+ data +' </span></div>',
        "",
        {
          timeOut: 3000,
          closeButton: true,
          enableHtml: true,
          tapToDismiss: false,
          titleClass: "alert-title",
          positionClass: "toast-top-center",
          toastClass:
            "ngx-toastr alert alert-dismissible alert-danger alert-notify"
        }
      );
  
  
    }
 
  

    selectedEntries = [];
    allSelected = false;
    selectRow(e, fileNo) {
      if(e.target.checked) {
        this.selectedEntries.push(fileNo);
      } else {
        this.selectedEntries.splice(this.selectedEntries.indexOf(fileNo), 1);
      }

      // check if all rows are individually selected
      if(this._FilteredList.length === this.selectedEntries.length) {
        setTimeout(() => {
          this.allSelected = true;
        }, 100);
      } else {
        setTimeout(() => {
          this.allSelected = false;
        }, 100);
      }
      console.log(this.selectedEntries);
     }

    selectAll(e) {
      console.log('All files selected');
      if(e.target.checked) {
        this._FilteredList.forEach(element => {
          this.selectedEntries.push(element.FileNo);
        });
      } else {
        this.selectedEntries = [];
      }
    }
 
    paginate(e) {
      this.first = e.first;
      this.rows = e.rows;
    }

     
 
            formattedData: any = [];
            headerList: any;
            immutableFormattedData: any;
            loading: boolean = true;
            prepareTableData(tableData, headerList) {
              let formattedData = [];
              let tableHeader: any = [
                { field: 'srNo', header: "SR NO", index: 1 },
                { field: 'BatchNo', header: 'BATCH ID ', index: 2 },
                 { field: 'PODNo', header: 'PODNO', index: 2 },
                //  { field: 'CartonNo', header: 'CARTON NO', index: 3 },    
                 { field: 'LANNo', header: 'LAN NO', index: 3 },               
                 { field: 'CustomerName', header: 'CUSTOMER NAME', index: 3 },               
                 { field: 'JCName', header: 'JC NAME', index: 3 },
                 { field: 'JCCode', header: 'JC CODE', index: 3 },               
              { field: 'FileNo', header: 'FILE NO', index: 3 },             
                { field: 'DocumentType', header: 'DOCUMENT TYPE', index: 6 },
                { field: 'Courier', header: 'COURIER', index: 3 },           
               
                { field: 'FileStatus', header: 'FILE STATUS', index: 3 },     
                { field: 'Status', header: 'POD STATUS', index: 3 },   
                // { field: 'Batchstatus', header: 'BATCH STATUS', index: 3 },  
                // { field: 'AcknowledgeDate', header: 'ACKNOWLEDGE DATE', index: 3 },    
                
                 
              ];
           
              tableData.forEach((el, index) => {
                formattedData.push({
                  'srNo': parseInt(index + 1),
                  'BatchNo': el.BatchNo,           
                  'PODNo': el.PODNo,   
                  "LANNo": el.LANNo,
                  "DocumentType": el.DocumentType, 
                  'FileNo': el.FileNo, 
                  'CartonNo': el.CartonNo,
                  'Status': el.Status,
                  'FileStatus': el.FileStatus,   
                  'AuditorID': el.AuditorID,
                  'Courier': el.Courier,    
                  'Batchstatus': el.Batchstatus,   
                  'AcknowledgeDate': el.AcknowledgeDate, 
                  'CustomerName': el.CustomerName, 
                  'JCName': el.JCName,
                  'JCCode': el.JCCode,                   
       
                });
              
              });
              this.headerList = tableHeader;
              this.immutableFormattedData = JSON.parse(JSON.stringify(formattedData));
              this.formattedData = formattedData;
              this.loading = false;
              

          //    console.log(this.formattedData);

            }
        
            searchTable($event) {
              // console.log($event.target.value);
          
              let val = $event.target.value;
              if(val == '') {
                this.formattedData = this.immutableFormattedData;
              } else {
                let filteredArr = [];
                const strArr = val.split(',');
                this.formattedData = this.immutableFormattedData.filter(function (d) {
                  for (var key in d) {
                    strArr.forEach(el => {
                      if (d[key] && el!== '' && (d[key]+ '').toLowerCase().indexOf(el.toLowerCase()) !== -1) {
                        if (filteredArr.filter(el => el.srNo === d.srNo).length === 0) {
                          filteredArr.push(d);
                        }
                      }
                    });
                  }
                });
                this.formattedData = filteredArr;
              }
            }


            
  GetHeaderNames()
  {
    this._HeaderList="";
    for (let j = 0; j < this._ColNameList.length; j++) {  
         
        this._HeaderList += this._ColNameList[j] +((j <= this._ColNameList.length-2)?',':'') ;
      // headerArray.push(headers[j]);  
    }
    this._HeaderList += '\n'
    this._FilteredList.forEach(stat => {
      for (let j = 0; j < this._ColNameList.length; j++) {  
        this._HeaderList += (stat[this._ColNameList[j]]) + ((j <= this._ColNameList.length-2)?',':'') ;
        // headerArray.push(headers[j]);  
      }
      this._HeaderList += '\n'
    });
    
  
  }
  
  downloadFile() { 
    this.GetHeaderNames()
    let csvData = this._HeaderList;     
    var csvDatas = csvData.replace("null", ""); 

   // console.log(csvData) 
    if(this._FilteredList.length>0) {
    let blob = new Blob(['\ufeff' +  csvDatas], { 
        type: 'text/csv;charset=utf-8;'
    }); 
    let dwldLink = document.createElement("a"); 
    let url = URL.createObjectURL(blob); 
    let isSafariBrowser =-1;
    // let isSafariBrowser = navigator.userAgent.indexOf( 'Safari') != -1 & amp; & amp; 
    // navigator.userAgent.indexOf('Chrome') == -1; 
    
    //if Safari open in new window to save file with random filename. 
    if (isSafariBrowser) {  
        dwldLink.setAttribute("target", "_blank"); 
    } 
    dwldLink.setAttribute("href", url); 
    dwldLink.setAttribute("download",  "Download" + ".csv"); 
    dwldLink.style.visibility = "hidden"; 
    document.body.appendChild(dwldLink); 
    dwldLink.click(); 
    document.body.removeChild(dwldLink); 
  } else {
    this.toastr.show(
      '<div class="alert-text"</div> <span class="alert-title" data-notify="title">Error!</span> <span data-notify="message">There should be some data before you download!</span></div>',
      "",
      {
        timeOut: 3000,
        closeButton: true,
        enableHtml: true,
        tapToDismiss: false,
        titleClass: "alert-title",
        positionClass: "toast-top-center",
        toastClass:
          "ngx-toastr alert alert-dismissible alert-danger alert-notify"
      }
    );
  }
  }

  ViewHealthCheck(Row: any) {
        
    localStorage.setItem('BatchNo', Row.BatchNo);
    localStorage.setItem('LANNo', Row.LANNo);
   // alert(Row.LANNo);
    //this.localStorage.setItem('_TempID') =_TempID;
    this.router.navigate(['/process/HealthCheckView']);
  } 

}
