import { Routes } from "@angular/router";
 
 
 
export const uploadRoutes: Routes = [
  {
    path: "",
    children: [
      // {
     

      
    ]
  }
];
