import { Routes } from "@angular/router";
  

export const reportRoutes: Routes = [
  {
    path: "",
    children: [
      {
         
      }
    ]

  }
];
