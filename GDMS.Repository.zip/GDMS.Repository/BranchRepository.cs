﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using GDMS.Entities;
using GDMS.Repository.Interfaces;

namespace GDMS.Repository
{
public	class BranchRepository : BaseRepository, IRepository<BranchEntity>
	{
		public IEnumerable<BranchEntity> Get()
		{
			try
			{
				IList<BranchEntity> resultList = SqlMapper.Query<BranchEntity>(ConnectionString, "GetBranches", commandType: CommandType.StoredProcedure).ToList();
				return resultList;
			}
			catch (Exception ex)
			{

				throw;
			}
		}

		public BranchEntity Get(int id)
		{
			try
			{
				DynamicParameters parameters = new DynamicParameters();
				parameters.Add("@USERID", id);
				return SqlMapper.Query<BranchEntity>(ConnectionString, "GetBranchList", parameters, commandType: CommandType.StoredProcedure).FirstOrDefault();
			}
			catch (Exception)
			{
				throw;
			}
		}

              
        public string Add(BranchEntity entity)
		{
			try
			{
				return AddUpdate(entity);
			}
			catch (Exception ex)
			{
				throw;
			}
		}
		public string Update(BranchEntity entity)
		{
			try
			{
				return AddUpdate(entity);				

			}
			catch (Exception ex)
			{
				throw;
			}
		}
		public bool Delete(int id)
		{
			try
			{
				DynamicParameters parameters = new DynamicParameters();
				parameters.Add("@Id", id);
				parameters.Add("@Msg", "", direction: ParameterDirection.Output);
				SqlMapper.Execute(ConnectionString, "usp_DeleteBranch", param: parameters, commandType: CommandType.StoredProcedure);
				string val = parameters.Get<string>("@Msg");

                if (val.Trim()== "Deleted successfully")
				{
					return true;
				}
				return false;
			}
			catch (Exception)
			{
				throw;
			}
		}

		private string AddUpdate(BranchEntity entity)
		{
			DynamicParameters parameters = new DynamicParameters();
			parameters.Add("@iID", entity.id);
			parameters.Add("@BranchName", entity.BranchName);
			parameters.Add("@DepartmentID", entity.DepartmentID);
			parameters.Add("@MSG","", direction: ParameterDirection.Output);		
			SqlMapper.Execute(ConnectionString, "sp_AddEditBranch", param: parameters, commandType: CommandType.StoredProcedure);

			return parameters.Get<string>("@MSG");
		}

		public string SFTpFileUpdate(AdminEntity entity)
		{
			throw new NotImplementedException();
		}

        public string SFTpFileUpdate(BranchEntity entity)
        {
            throw new NotImplementedException();
        }

        public bool UpdateFileCount(int FileCount, string CustomerName)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<BranchEntity> GetFileStatus(int RegionID, int CustomerID)
        {
            throw new NotImplementedException();
        }
    }
}
