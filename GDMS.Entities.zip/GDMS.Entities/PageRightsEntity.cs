﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDMS.Entities
{
	public class PageRightsEntity
	{
		public int? id { get; set; }
		public string page_right { get; set; }
	}
}
