﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDMS.Entities
{
	public class MenuMappingEntity
	{

		public int? mid { get; set; }	
		public int? page_id { get; set; }
		public int? role_id { get; set; }
	}
}
