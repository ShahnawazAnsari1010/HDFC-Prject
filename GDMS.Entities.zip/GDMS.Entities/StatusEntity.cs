﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDMS.Entities
{
	public class StatusEntity : BaseEntity
	{
		public int? id { get; set; }
		public string AGEEMENTNO { get; set; }
        public string BARCODE { get; set; }
        public string PRODUCTNAME { get; set; }
        public string DISBURSEMENTDATE { get; set; }
        public string CUSTOMERNAME { get; set; }
        public string SYSTEM { get; set; }
        public DateTime DATETO { get; set; }
        public DateTime DATEFROM { get; set; }
        public string CASESTARTERBRANCH { get; set; }
        public string GENERATEDON { get; set; }
        public string CPUID { get; set; }
        public string batch_id { get; set; }
        public string RepaymentMode { get; set; }
        public string VendorLocation { get; set; }
        public string VendorID { get; set; }
        public string BoxNo { get; set; }
        public string CartonNo { get; set; }
        public string PODRECDDate { get; set; }
        public string ReceiptDate { get; set; }
        public string PODNo { get; set; }
        public string PODdetails { get; set; }
        public string CourierName { get; set; }
        public string FileBarcode { get; set; }
      
        
        public string USERID { get; set; }
        public string EntryDate { get; set; }

        public string ECCartonNo { get; set; }
        public string ECBarcode { get; set; }

        public string Status { get; set; }
        //public int TagID { get; set; }
   
      
        public string Remark { get; set; }
        public string SendDate { get; set; }
        public string LoginDate { get; set; }

      //  public string FileNo { get; set; }

        public string DownloadDate { get; set; }

     

    }
}
