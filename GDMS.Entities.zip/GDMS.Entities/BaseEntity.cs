﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GDMS.Entities
{
    public class BaseEntity
    {
		public DateTime? DateCreated { get; set; }
		public int CreatedBy { get; set; }
		public string User_Token { get; set; }
	}
}
